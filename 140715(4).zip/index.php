<html>
<head>
	<title>
		filelist
	</title>
</head>
<body>
	<form action="upload.php" method="post" enctype="multipart/form-data">
		<input type="file" name="file">
		<input type="submit" value="upload">
	</form>
<?php
	if(!file_exists('upload')){
		mkdir('upload');
	}
	$dir = opendir("upload");
	while($filename = readdir($dir)){
		if ($filename!="."&&$filename!="..") {
			echo "<a href=\"download.php?filename=$filename\">$filename</a><br>";
		}
	}
	closedir($dir);
?>
</body>
</html>
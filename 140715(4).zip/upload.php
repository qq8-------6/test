<?php
	if(isset($_FILES['file'])){
		if(!file_exists('upload')){
			mkdir('upload');
		}
		move_uploaded_file($_FILES['file']['tmp_name'], 'upload\\'.$_FILES['file']['name']);
		echo "<h3>success!!</h3><br>";
	}else{
		echo "<h3>error</h3><br>";
	}
	echo '<a href="index.php">return to index</a>';
<?php

	if(!isset($_GET['filename'])){
		echo "error";
		die();
	}
	$filename=$_GET['filename'];
	header("Content-Disposition:attachment;filename=$filename");
	header("Content-Length:".filesize($filename));
	readfile($filename);